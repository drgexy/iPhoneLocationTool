#!/bin/bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="iPhone Location Tool.app"
BUNDLE="$APP_DIR/$APP_NAME"
EXECUTABLE="$BUNDLE/Contents/MacOS/iPhoneLocationTool"
ASSET_DIR="$APP_DIR/NativeApp/Assets"
if [[ -d "/Applications/Xcode-beta.app/Contents/Developer" ]]; then
  export DEVELOPER_DIR="/Applications/Xcode-beta.app/Contents/Developer"
elif [[ -d "/Applications/Xcode.app/Contents/Developer" ]]; then
  export DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer"
fi

cd "$APP_DIR"

rm -rf "$BUNDLE"
mkdir -p "$BUNDLE/Contents/MacOS" "$BUNDLE/Contents/Resources"

if [[ -x "$APP_DIR/.venv/bin/python" ]]; then
  "$APP_DIR/.venv/bin/python" "$APP_DIR/NativeApp/generate_icon.py" "$ASSET_DIR"
elif python3 - <<'PY' >/dev/null 2>&1
import PIL
PY
then
  python3 "$APP_DIR/NativeApp/generate_icon.py" "$ASSET_DIR"
else
  echo "Pillow is not available; skipping icon generation."
fi

cat > "$BUNDLE/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDevelopmentRegion</key>
  <string>zh_CN</string>
  <key>CFBundleDisplayName</key>
  <string>iPhone Location Tool</string>
  <key>CFBundleExecutable</key>
  <string>iPhoneLocationTool</string>
  <key>CFBundleIconFile</key>
  <string>AppIcon</string>
  <key>CFBundleIdentifier</key>
  <string>local.iphone-location-tool</string>
  <key>CFBundleInfoDictionaryVersion</key>
  <string>6.0</string>
  <key>CFBundleName</key>
  <string>iPhone Location Tool</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleShortVersionString</key>
  <string>1.1</string>
  <key>CFBundleVersion</key>
  <string>2</string>
  <key>LSMinimumSystemVersion</key>
  <string>13.0</string>
  <key>NSHighResolutionCapable</key>
  <true/>
</dict>
</plist>
PLIST

if [[ -f "$ASSET_DIR/AppIcon.icns" ]]; then
  cp "$ASSET_DIR/AppIcon.icns" "$BUNDLE/Contents/Resources/AppIcon.icns"
fi
if [[ -f "$ASSET_DIR/AppLogo.png" ]]; then
  cp "$ASSET_DIR/AppLogo.png" "$BUNDLE/Contents/Resources/AppLogo.png"
fi

MACOSX_DEPLOYMENT_TARGET=13.0 xcrun swiftc \
  -O \
  -target arm64-apple-macosx13.0 \
  -framework Cocoa \
  "$APP_DIR/NativeApp/main.swift" \
  -o "$EXECUTABLE"

chmod +x "$EXECUTABLE"
xattr -cr "$BUNDLE" || true
touch "$BUNDLE"

echo "Created native app: $BUNDLE"
if [[ -t 0 ]]; then
  read -r -p "Press Enter to close this window..."
fi
