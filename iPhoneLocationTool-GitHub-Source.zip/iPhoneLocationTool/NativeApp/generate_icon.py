#!/usr/bin/env python3
from __future__ import annotations

import math
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter


def rounded_rectangle_mask(size: int, radius: int) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle((0, 0, size, size), radius=radius, fill=255)
    return mask


def draw_pin(draw: ImageDraw.ImageDraw, cx: int, cy: int, scale: float) -> None:
    r = int(104 * scale)
    point_y = int(cy + 260 * scale)
    circle_box = (cx - r, cy - r, cx + r, cy + r)
    fill = (255, 74, 86, 255)
    edge = (255, 255, 255, 255)
    shadow = (25, 29, 45, 70)

    draw.ellipse((circle_box[0] + 14, circle_box[1] + 18, circle_box[2] + 14, circle_box[3] + 18), fill=shadow)
    draw.polygon([(cx - int(72 * scale) + 14, cy + int(70 * scale) + 18),
                  (cx + int(72 * scale) + 14, cy + int(70 * scale) + 18),
                  (cx + 14, point_y + 18)], fill=shadow)

    draw.ellipse(circle_box, fill=fill, outline=edge, width=int(14 * scale))
    draw.polygon([(cx - int(72 * scale), cy + int(70 * scale)),
                  (cx + int(72 * scale), cy + int(70 * scale)),
                  (cx, point_y)], fill=fill)
    draw.line([(cx - int(55 * scale), cy + int(92 * scale)),
               (cx, point_y - int(6 * scale)),
               (cx + int(55 * scale), cy + int(92 * scale))],
              fill=edge, width=int(12 * scale), joint="curve")
    draw.ellipse((cx - int(42 * scale), cy - int(42 * scale),
                  cx + int(42 * scale), cy + int(42 * scale)),
                 fill=(255, 255, 255, 255))


def create_icon(size: int) -> Image.Image:
    scale = size / 1024
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    mask = rounded_rectangle_mask(size, int(220 * scale))

    base = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(base)
    for y in range(size):
        t = y / max(1, size - 1)
        r = int(23 + 13 * t)
        g = int(92 + 40 * t)
        b = int(176 + 36 * t)
        draw.line([(0, y), (size, y)], fill=(r, g, b, 255))

    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    gdraw.ellipse((int(-120 * scale), int(-120 * scale), int(620 * scale), int(620 * scale)),
                  fill=(80, 210, 255, 80))
    gdraw.ellipse((int(500 * scale), int(420 * scale), int(1120 * scale), int(1080 * scale)),
                  fill=(37, 214, 158, 64))
    glow = glow.filter(ImageFilter.GaussianBlur(int(28 * scale)))
    base.alpha_composite(glow)

    draw = ImageDraw.Draw(base)
    grid_color = (255, 255, 255, 45)
    for i in range(-1, 8):
        x = int((i * 170 + 30) * scale)
        draw.line([(x, 0), (x + int(220 * scale), size)], fill=grid_color, width=max(1, int(4 * scale)))
    for i in range(1, 7):
        y = int(i * 145 * scale)
        draw.arc((int(-180 * scale), y - int(380 * scale), int(1180 * scale), y + int(380 * scale)),
                 8, 172, fill=grid_color, width=max(1, int(4 * scale)))

    phone = (
        int(210 * scale),
        int(158 * scale),
        int(692 * scale),
        int(866 * scale),
    )
    shadow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    sdraw = ImageDraw.Draw(shadow)
    sdraw.rounded_rectangle((phone[0] + int(24 * scale), phone[1] + int(28 * scale),
                             phone[2] + int(24 * scale), phone[3] + int(28 * scale)),
                            radius=int(78 * scale), fill=(0, 0, 0, 75))
    shadow = shadow.filter(ImageFilter.GaussianBlur(int(20 * scale)))
    base.alpha_composite(shadow)

    draw.rounded_rectangle(phone, radius=int(78 * scale), fill=(248, 252, 255, 255))
    draw.rounded_rectangle((phone[0] + int(30 * scale), phone[1] + int(46 * scale),
                            phone[2] - int(30 * scale), phone[3] - int(58 * scale)),
                           radius=int(44 * scale), fill=(222, 238, 248, 255))
    draw.rounded_rectangle((int(378 * scale), int(188 * scale), int(524 * scale), int(220 * scale)),
                           radius=int(16 * scale), fill=(33, 55, 86, 255))

    route = [
        (int(300 * scale), int(650 * scale)),
        (int(380 * scale), int(570 * scale)),
        (int(474 * scale), int(614 * scale)),
        (int(560 * scale), int(492 * scale)),
        (int(655 * scale), int(526 * scale)),
    ]
    draw.line(route, fill=(25, 130, 230, 255), width=int(18 * scale), joint="curve")
    for x, y in route:
        draw.ellipse((x - int(15 * scale), y - int(15 * scale),
                      x + int(15 * scale), y + int(15 * scale)), fill=(255, 255, 255, 255))

    draw_pin(draw, int(666 * scale), int(362 * scale), scale)

    shine = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    shdraw = ImageDraw.Draw(shine)
    shdraw.polygon([(0, 0), (int(380 * scale), 0), (0, int(410 * scale))], fill=(255, 255, 255, 36))
    base.alpha_composite(shine)

    img.alpha_composite(base)
    img.putalpha(mask)
    return img


def main() -> int:
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("Assets")
    out_dir.mkdir(parents=True, exist_ok=True)
    icon = create_icon(1024)
    icon.save(out_dir / "AppLogo.png")

    iconset = out_dir / "AppIcon.iconset"
    if iconset.exists():
        shutil.rmtree(iconset)
    iconset.mkdir()

    sizes = [
        (16, "icon_16x16.png"),
        (32, "icon_16x16@2x.png"),
        (32, "icon_32x32.png"),
        (64, "icon_32x32@2x.png"),
        (128, "icon_128x128.png"),
        (256, "icon_128x128@2x.png"),
        (256, "icon_256x256.png"),
        (512, "icon_256x256@2x.png"),
        (512, "icon_512x512.png"),
        (1024, "icon_512x512@2x.png"),
    ]
    for px, name in sizes:
        resample = Image.Resampling.LANCZOS
        icon.resize((px, px), resample).save(iconset / name)

    subprocess.run(["iconutil", "-c", "icns", str(iconset), "-o", str(out_dir / "AppIcon.icns")], check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
