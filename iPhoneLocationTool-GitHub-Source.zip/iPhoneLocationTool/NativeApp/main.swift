import Cocoa

struct ToolDevice {
    let id: String
    let name: String
    let version: String
    let state: String
    let runtime: String
}

struct CommandResult {
    let code: Int32
    let output: String
}

struct XcodeInstallation {
    let appURL: URL
    let version: String

    var name: String {
        appURL.deletingPathExtension().lastPathComponent
    }

    var majorVersion: Int? {
        version.split(separator: ".").first.flatMap { Int($0) }
    }

    var deviceHubURL: URL {
        appURL.appendingPathComponent("Contents/Applications/DeviceHub.app")
    }

    var hasDeviceHub: Bool {
        FileManager.default.fileExists(atPath: deviceHubURL.path)
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var window: NSWindow!
    private var realDevices: [ToolDevice] = []
    private var simDevices: [ToolDevice] = []
    private var isBusy = false
    private var activeSimulationProcess: Process?

    private let modePopup = NSPopUpButton()
    private let realPopup = NSPopUpButton()
    private let simPopup = NSPopUpButton()
    private let channelPopup = NSPopUpButton()
    private let presetPopup = NSPopUpButton()
    private let latField = NSTextField(string: "31.230416")
    private let lonField = NSTextField(string: "121.473701")
    private let userspaceCheck = NSButton(checkboxWithTitle: "iOS 17+ 使用免管理员 userspace tunnel", target: nil, action: nil)
    private let logView = NSTextView()
    private let statusLabel = NSTextField(labelWithString: "正在初始化...")

    private let presets: [(String, Double, Double)] = [
        ("上海 人民广场", 31.230416, 121.473701),
        ("Apple Park", 37.334900, -122.009020),
        ("英国 伦敦眼", 51.503324, -0.119543),
        ("北京 天安门", 39.908722, 116.397499),
        ("深圳 市民中心", 22.543096, 114.057865),
        ("香港 中环", 22.281928, 114.158997),
        ("东京站", 35.681236, 139.767125),
        ("纽约 自由女神像", 40.689249, -74.044500)
    ]

    private var toolRoot: URL {
        if Bundle.main.bundleURL.pathExtension == "app" {
            return Bundle.main.bundleURL.deletingLastPathComponent()
        }
        return URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        applyAppIcon()
        NSApp.activate(ignoringOtherApps: true)
        buildWindow()
        statusLabel.stringValue = "已打开。连接 iPhone 后点击“刷新设备”。"
        log("工具已启动。连接并信任 iPhone 后，请点击“刷新设备”。")
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        true
    }

    private func buildWindow() {
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 1040, height: 760),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "iPhone Location Tool"
        window.minSize = NSSize(width: 960, height: 680)
        window.center()

        let root = NSView()
        window.contentView = root

        let title = NSTextField(labelWithString: "iPhone Location Tool")
        title.font = .boldSystemFont(ofSize: 24)

        let brand = NSStackView(views: [logoView(), title])
        brand.orientation = .horizontal
        brand.alignment = .centerY
        brand.spacing = 10

        let notice = NSTextField(wrappingLabelWithString: "仅用于你本人设备上的 App 开发、调试和测试定位。设置定位时请保持手机解锁且屏幕亮起；模拟定位不会自动修改系统时区。")
        notice.textColor = .secondaryLabelColor

        let header = NSStackView(views: [brand, spacer(), makeButton("刷新设备", #selector(refreshAll(_:)))])
        header.orientation = .horizontal
        header.alignment = .centerY
        header.spacing = 12

        let left = NSStackView()
        left.orientation = .vertical
        left.alignment = .width
        left.spacing = 12
        left.translatesAutoresizingMaskIntoConstraints = false
        left.widthAnchor.constraint(equalToConstant: 380).isActive = true
        left.addArrangedSubview(targetBox())
        left.addArrangedSubview(locationBox())
        left.addArrangedSubview(actionBox())
        left.addArrangedSubview(spacer())

        let logTitle = NSStackView(views: [label("运行日志", bold: true), spacer(), makeButton("清空", #selector(clearLog(_:)))])
        logTitle.orientation = .horizontal
        logTitle.alignment = .centerY
        logTitle.spacing = 8

        logView.isEditable = false
        logView.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        logView.textContainerInset = NSSize(width: 10, height: 10)
        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.borderType = .bezelBorder
        scroll.documentView = logView

        let right = NSStackView(views: [logTitle, scroll])
        right.orientation = .vertical
        right.alignment = .width
        right.spacing = 8
        right.translatesAutoresizingMaskIntoConstraints = false

        let body = NSStackView(views: [left, right])
        body.orientation = .horizontal
        body.alignment = .top
        body.spacing = 16
        body.translatesAutoresizingMaskIntoConstraints = false

        let outer = NSStackView(views: [header, notice, body, statusLabel])
        outer.orientation = .vertical
        outer.spacing = 12
        outer.translatesAutoresizingMaskIntoConstraints = false
        root.addSubview(outer)

        NSLayoutConstraint.activate([
            outer.leadingAnchor.constraint(equalTo: root.leadingAnchor, constant: 18),
            outer.trailingAnchor.constraint(equalTo: root.trailingAnchor, constant: -18),
            outer.topAnchor.constraint(equalTo: root.topAnchor, constant: 18),
            outer.bottomAnchor.constraint(equalTo: root.bottomAnchor, constant: -14),
            scroll.heightAnchor.constraint(greaterThanOrEqualToConstant: 500)
        ])

        window.makeKeyAndOrderFront(nil)
        DispatchQueue.main.async {
            self.window.makeFirstResponder(nil)
        }
    }

    private func targetBox() -> NSView {
        modePopup.addItems(withTitles: ["真机 iPhone", "iOS 模拟器"])
        channelPopup.addItems(withTitles: ["auto", "ios17_dvt", "ios16_legacy"])
        userspaceCheck.state = .on

        let stack = verticalStack([
            sectionTitle("目标设备"),
            formRow("模式", modePopup),
            formRow("已连接 iPhone", realPopup),
            formRow("模拟器", simPopup),
            formRow("定位通道", channelPopup),
            smallLabel("auto 会先读取 iOS 版本；iOS 17+ 使用 DVT，iOS 16 及以下使用旧通道。"),
            padded(userspaceCheck)
        ])
        return boxed(stack)
    }

    private func locationBox() -> NSView {
        presetPopup.addItems(withTitles: presets.map { $0.0 })
        presetPopup.target = self
        presetPopup.action = #selector(applyPreset(_:))

        let exportButton = makeButton("导出 GPX", #selector(exportGPX(_:)))
        exportButton.translatesAutoresizingMaskIntoConstraints = false
        exportButton.widthAnchor.constraint(equalToConstant: 340).isActive = true

        let stack = verticalStack([
            sectionTitle("定位坐标"),
            formRow("常用位置", presetPopup),
            formRow("纬度", latField),
            formRow("经度", lonField),
            exportButton
        ])
        return boxed(stack)
    }

    private func actionBox() -> NSView {
        let setButton = makeButton("设置到此位置", #selector(setLocation(_:)))
        setButton.bezelColor = NSColor.controlAccentColor
        let endButton = makeButton("结束模拟", #selector(endSimulation(_:)))
        endButton.bezelColor = NSColor.systemRed
        let clearButton = makeButton("清除模拟定位", #selector(clearLocation(_:)))
        let developerButton = makeButton("检测开发者模式", #selector(checkDeveloperMode(_:)))
        let xcodeButton = makeButton("打开设备管理", #selector(openXcode(_:)))
        let checkButton = makeButton("检查环境", #selector(checkEnvironment(_:)))
        [setButton, endButton, clearButton, developerButton, xcodeButton, checkButton].forEach { button in
            button.translatesAutoresizingMaskIntoConstraints = false
            button.widthAnchor.constraint(equalToConstant: 340).isActive = true
        }
        return boxed(verticalStack([
            sectionTitle("操作"),
            setButton,
            endButton,
            clearButton,
            developerButton,
            xcodeButton,
            checkButton
        ]))
    }

    private func label(_ text: String, bold: Bool = false, size: CGFloat = 13) -> NSTextField {
        let field = NSTextField(labelWithString: text)
        field.font = bold ? .boldSystemFont(ofSize: size) : .systemFont(ofSize: size)
        field.lineBreakMode = .byTruncatingTail
        return field
    }

    private func sectionTitle(_ text: String) -> NSTextField {
        let field = label(text, bold: true, size: 14)
        field.alignment = .left
        field.translatesAutoresizingMaskIntoConstraints = false
        field.widthAnchor.constraint(equalToConstant: 340).isActive = true
        field.setContentHuggingPriority(.required, for: .vertical)
        return field
    }

    private func smallLabel(_ text: String) -> NSTextField {
        let field = NSTextField(wrappingLabelWithString: text)
        field.font = .systemFont(ofSize: 12)
        field.textColor = .secondaryLabelColor
        field.maximumNumberOfLines = 3
        field.translatesAutoresizingMaskIntoConstraints = false
        field.widthAnchor.constraint(equalToConstant: 340).isActive = true
        return field
    }

    private func makeButton(_ title: String, _ action: Selector) -> NSButton {
        let button = NSButton(title: title, target: self, action: action)
        button.bezelStyle = .rounded
        button.controlSize = .regular
        return button
    }

    private func applyAppIcon() {
        if let iconURL = Bundle.main.url(forResource: "AppLogo", withExtension: "png"),
           let image = NSImage(contentsOf: iconURL) {
            NSApp.applicationIconImage = image
        }
    }

    private func logoView() -> NSImageView {
        let imageView = NSImageView()
        imageView.imageScaling = .scaleProportionallyUpOrDown
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.widthAnchor.constraint(equalToConstant: 36).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 36).isActive = true
        if let iconURL = Bundle.main.url(forResource: "AppLogo", withExtension: "png") {
            imageView.image = NSImage(contentsOf: iconURL)
        }
        return imageView
    }

    private func spacer() -> NSView {
        let view = NSView()
        view.setContentHuggingPriority(.defaultLow, for: .horizontal)
        view.setContentHuggingPriority(.defaultLow, for: .vertical)
        return view
    }

    private func verticalStack(_ views: [NSView]) -> NSStackView {
        let stack = NSStackView(views: views)
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }

    private func formRow(_ title: String, _ control: NSView) -> NSStackView {
        let titleLabel = label(title)
        titleLabel.alignment = .right
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.widthAnchor.constraint(equalToConstant: 86).isActive = true

        control.translatesAutoresizingMaskIntoConstraints = false
        control.heightAnchor.constraint(greaterThanOrEqualToConstant: 28).isActive = true
        control.widthAnchor.constraint(equalToConstant: 240).isActive = true

        let row = NSStackView(views: [titleLabel, control])
        row.orientation = .horizontal
        row.alignment = .centerY
        row.spacing = 10
        row.translatesAutoresizingMaskIntoConstraints = false
        return row
    }

    private func padded(_ view: NSView) -> NSView {
        let container = NSView()
        container.translatesAutoresizingMaskIntoConstraints = false
        view.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(view)
        NSLayoutConstraint.activate([
            view.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 2),
            view.trailingAnchor.constraint(lessThanOrEqualTo: container.trailingAnchor),
            view.topAnchor.constraint(equalTo: container.topAnchor),
            view.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        return container
    }

    private func boxed(_ content: NSView) -> NSView {
        let container = NSView()
        container.wantsLayer = true
        container.layer?.backgroundColor = NSColor.controlBackgroundColor.cgColor
        container.layer?.borderColor = NSColor.separatorColor.cgColor
        container.layer?.borderWidth = 1
        container.layer?.cornerRadius = 8
        container.translatesAutoresizingMaskIntoConstraints = false

        content.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(content)

        NSLayoutConstraint.activate([
            content.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 14),
            content.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -14),
            content.topAnchor.constraint(equalTo: container.topAnchor, constant: 14),
            content.bottomAnchor.constraint(equalTo: container.bottomAnchor, constant: -14),
            container.widthAnchor.constraint(equalToConstant: 380)
        ])

        return container
    }

    @objc private func applyPreset(_ sender: Any?) {
        let index = presetPopup.indexOfSelectedItem
        guard presets.indices.contains(index) else { return }
        latField.stringValue = String(format: "%.6f", presets[index].1)
        lonField.stringValue = String(format: "%.6f", presets[index].2)
    }

    @objc private func clearLog(_ sender: Any?) {
        logView.string = ""
    }

    @objc private func refreshAll(_ sender: Any?) {
        runTask("正在刷新设备...") {
            self.refreshRealDevices()
            self.refreshSimulators()
            self.log("设备列表已刷新。")
        }
    }

    @objc private func checkEnvironment(_ sender: Any?) {
        runTask("正在检查环境...") {
            self.log("环境检查：")
            self.log("- 工具目录：\(self.toolRoot.path)")
            self.log("- xcrun：\(FileManager.default.fileExists(atPath: "/usr/bin/xcrun") ? "/usr/bin/xcrun" : "未找到")")
            if let pymo = self.pymoPath() {
                self.log("- pymobiledevice3：\(pymo)")
                let version = self.runCommand([pymo, "version"], timeout: 15)
                self.log("- pymobiledevice3 版本：\(version.output.trimmingCharacters(in: .whitespacesAndNewlines))")
            } else {
                self.log("- pymobiledevice3：未找到，请运行 install_dependencies.command")
            }
            let xcodes = self.findXcodeInstallations()
            if xcodes.isEmpty {
                self.log("- Xcode：未找到")
            } else {
                for xcode in xcodes {
                    let deviceTool = xcode.hasDeviceHub ? "Device Hub" : "Devices and Simulators"
                    self.log("- Xcode：\(xcode.name) \(xcode.version)，设备入口：\(deviceTool)，路径：\(xcode.appURL.path)")
                }
            }
        }
    }

    @objc private func setLocation(_ sender: Any?) {
        guard let coords = readCoordinates() else { return }
        if modePopup.indexOfSelectedItem == 1 {
            runTask("正在设置模拟器定位...") {
                try self.setSimulatorLocation(lat: coords.0, lon: coords.1)
            }
        } else {
            runTask("正在设置 iPhone 定位...") {
                try self.setRealLocation(lat: coords.0, lon: coords.1)
            }
        }
    }

    @objc private func clearLocation(_ sender: Any?) {
        if modePopup.indexOfSelectedItem == 1 {
            runTask("正在清除模拟器定位...") {
                self.terminateLocalSimulationProcesses()
                try self.clearSimulatorLocation()
            }
        } else {
            runTask("正在清除 iPhone 模拟定位...") {
                self.terminateLocalSimulationProcesses()
                try self.clearRealLocation()
            }
        }
    }

    @objc private func endSimulation(_ sender: Any?) {
        let simulatorMode = modePopup.indexOfSelectedItem == 1
        if simulatorMode {
            runTask("正在结束模拟器定位...") {
                self.terminateLocalSimulationProcesses()
                try self.clearSimulatorLocation()
            }
        } else {
            runTask("正在结束 iPhone 模拟定位...") {
                self.terminateLocalSimulationProcesses()
                try self.clearRealLocation()
            }
        }
    }

    @objc private func checkDeveloperMode(_ sender: Any?) {
        runTask("正在检测开发者模式...") {
            try self.checkSelectedDeviceDeveloperMode()
        }
    }

    @objc private func openXcode(_ sender: Any?) {
        guard let xcode = preferredXcodeInstallation() else {
            log("未找到 Xcode。请确认 Xcode 已安装，例如 /Applications/Xcode-beta.app 或 /Applications/Xcode.app。")
            return
        }

        log("识别到 Xcode：\(xcode.name) \(xcode.version)，路径：\(xcode.appURL.path)")

        if xcode.hasDeviceHub {
            NSWorkspace.shared.openApplication(at: xcode.deviceHubURL, configuration: NSWorkspace.OpenConfiguration()) { _, error in
                if let error {
                    self.log("打开 Device Hub 失败：\(error.localizedDescription)")
                } else {
                    self.log("已打开 Device Hub。请选中另一台 iPhone，等待设备准备完成；然后回到 iPhone 的 设置 > 隐私与安全性 查看“开发者模式”。")
                }
            }
        } else {
            NSWorkspace.shared.openApplication(at: xcode.appURL, configuration: NSWorkspace.OpenConfiguration()) { _, error in
                if let error {
                    self.log("打开 Xcode 失败：\(error.localizedDescription)")
                } else {
                    self.log("已打开旧版 Xcode。正在尝试打开 Window > Devices and Simulators；如果没有自动打开，请按 ⇧⌘2。")
                    DispatchQueue.global(qos: .userInitiated).async {
                        Thread.sleep(forTimeInterval: 2.0)
                        self.openLegacyDevicesAndSimulatorsWindow()
                    }
                }
            }
        }
    }

    @objc private func exportGPX(_ sender: Any?) {
        guard let coords = readCoordinates() else { return }
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "simulated-location.gpx"
        panel.allowedContentTypes = [.xml]
        panel.beginSheetModal(for: window) { response in
            guard response == .OK, let url = panel.url else { return }
            let text = """
            <?xml version="1.0" encoding="UTF-8"?>
            <gpx version="1.1" creator="iPhone Location Tool" xmlns="http://www.topografix.com/GPX/1/1">
              <metadata>
                <name>Simulated Location</name>
              </metadata>
              <wpt lat="\(String(format: "%.7f", coords.0))" lon="\(String(format: "%.7f", coords.1))">
                <name>Simulated Location</name>
              </wpt>
            </gpx>
            """
            do {
                try text.write(to: url, atomically: true, encoding: .utf8)
                self.log("已导出 GPX：\(url.path)")
            } catch {
                self.showError("导出失败：\(error.localizedDescription)")
            }
        }
    }

    private func runTask(_ status: String, _ work: @escaping () throws -> Void) {
        if isBusy {
            log("已有操作正在运行，请等待当前操作完成。")
            return
        }
        isBusy = true
        DispatchQueue.main.async {
            self.statusLabel.stringValue = status
        }
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try work()
                DispatchQueue.main.async {
                    self.isBusy = false
                    self.statusLabel.stringValue = "完成"
                }
            } catch {
                self.log("失败：\(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.isBusy = false
                    self.statusLabel.stringValue = "失败"
                    self.showError(error.localizedDescription)
                }
            }
        }
    }

    private func refreshRealDevices() {
        guard let pymo = pymoPath() else {
            log("未找到 pymobiledevice3：真机模式暂不可用。")
            DispatchQueue.main.async {
                self.realPopup.removeAllItems()
            }
            return
        }
        let devices: [ToolDevice]
        do {
            devices = try connectedRealDevices(pymo: pymo)
        } catch {
            log("读取 iPhone 列表失败：\(error.localizedDescription)")
            return
        }
        DispatchQueue.main.async {
            self.realDevices = devices
            self.realPopup.removeAllItems()
            self.realPopup.addItems(withTitles: devices.map { self.realLabel($0) })
        }
    }

    private func connectedRealDevices(pymo: String) throws -> [ToolDevice] {
        let result = runCommand([pymo, "usbmux", "list", "--simple"], timeout: 20)
        guard commandSucceeded(result) else {
            throw ToolError.message(result.output.isEmpty ? "未能读取 iPhone 列表。" : result.output)
        }
        let udids = parseUDIDs(result.output)
        var devices: [ToolDevice] = []
        for udid in udids {
            var name = "iPhone"
            var version = ""
            let info = runCommand([pymo, "lockdown", "info", "--udid", udid], timeout: 20)
            if commandSucceeded(info), let payload = jsonObject(info.output) {
                name = payload["DeviceName"] as? String ?? name
                version = payload["ProductVersion"] as? String ?? version
            } else if !info.output.isEmpty {
                log("读取 \(shortID(udid)) 详情失败：\(info.output)")
            }
            devices.append(ToolDevice(id: udid, name: name, version: version, state: "", runtime: ""))
        }
        return devices
    }

    private func refreshSimulators() {
        var devices = [ToolDevice(id: "booted", name: "当前已启动模拟器", version: "", state: "Booted", runtime: "")]
        let result = runCommand(["/usr/bin/xcrun", "simctl", "list", "devices", "--json"], timeout: 20)
        if commandSucceeded(result),
           let payload = jsonObject(result.output),
           let all = payload["devices"] as? [String: Any] {
            for (runtime, value) in all where runtime.contains("iOS") {
                guard let entries = value as? [[String: Any]] else { continue }
                for entry in entries where (entry["isAvailable"] as? Bool) != false {
                    devices.append(ToolDevice(
                        id: entry["udid"] as? String ?? "",
                        name: entry["name"] as? String ?? "iOS Simulator",
                        version: "",
                        state: entry["state"] as? String ?? "",
                        runtime: runtime.components(separatedBy: ".").last?.replacingOccurrences(of: "-", with: " ") ?? ""
                    ))
                }
            }
        } else {
            log("读取模拟器列表失败：\(result.output)")
        }
        DispatchQueue.main.async {
            self.simDevices = devices
            self.simPopup.removeAllItems()
            self.simPopup.addItems(withTitles: devices.map { self.simLabel($0) })
        }
    }

    private func setSimulatorLocation(lat: Double, lon: Double) throws {
        let device = try selectedSimulator()
        let coord = String(format: "%.7f,%.7f", lat, lon)
        log("设置模拟器 \(device.id) 到 \(coord)")
        let result = runCommand(["/usr/bin/xcrun", "simctl", "location", device.id, "set", coord], timeout: 30)
        log(result.output.isEmpty ? "命令完成。" : result.output)
        if !commandSucceeded(result) {
            throw ToolError.message("模拟器定位设置失败，请确认模拟器已启动。")
        }
    }

    private func clearSimulatorLocation() throws {
        let device = try selectedSimulator()
        log("清除模拟器 \(device.id) 的模拟定位")
        let result = runCommand(["/usr/bin/xcrun", "simctl", "location", device.id, "clear"], timeout: 30)
        log(result.output.isEmpty ? "命令完成。" : result.output)
        if !commandSucceeded(result) {
            throw ToolError.message("清除模拟器定位失败。")
        }
    }

    private func setRealLocation(lat: Double, lon: Double) throws {
        guard let pymo = pymoPath() else {
            throw ToolError.message("未找到 pymobiledevice3，请先运行 install_dependencies.command。")
        }
        let device = try selectedRealDevice()
        let path = resolvePath(version: device.version)
        try prepareDevice(pymo: pymo, udid: device.id, path: path)
        let commands = realLocationCommands(pymo: pymo, udid: device.id, path: path, action: "set", lat: lat, lon: lon)
        try startLongRunningSimulation(commands, failureMessage: "iPhone 定位设置失败。")
    }

    private func clearRealLocation() throws {
        guard let pymo = pymoPath() else {
            throw ToolError.message("未找到 pymobiledevice3，请先运行 install_dependencies.command。")
        }
        let device = try selectedRealDeviceOrSingleConnected(pymo: pymo)
        let path = resolvePath(version: device.version)
        let commands = realLocationCommands(pymo: pymo, udid: device.id, path: path, action: "clear", lat: nil, lon: nil)
        try runClearCommands(commands, failureMessage: "清除 iPhone 模拟定位失败。")
    }

    private func checkSelectedDeviceDeveloperMode() throws {
        guard let pymo = pymoPath() else {
            throw ToolError.message("未找到 pymobiledevice3，请先运行 install_dependencies.command。")
        }
        let device = try selectedRealDevice()
        log("检测开发者模式：\(device.name) \(device.version.isEmpty ? "" : "iOS \(device.version)")")

        let result = runCommand([pymo, "mounter", "query-developer-mode-status", "--udid", device.id], timeout: 25)
        let value = result.output.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if commandSucceeded(result), value.contains("true") {
            log("开发者模式：已开启。")
            return
        }
        if commandSucceeded(result), value.contains("false") {
            log("开发者模式：未开启。请按下面步骤打开。")
        } else {
            log("开发者模式状态读取失败：\(conciseOutput(result.output))")
        }
        logDeveloperModeGuide()
    }

    private func logDeveloperModeGuide() {
        let xcodeHint: String
        if let xcode = preferredXcodeInstallation() {
            if xcode.hasDeviceHub {
                xcodeHint = "检测到 \(xcode.name) \(xcode.version)：点击“打开设备管理”，会直接打开 Device Hub。"
            } else {
                xcodeHint = "检测到旧版 \(xcode.name) \(xcode.version)：点击“打开设备管理”，会尝试打开 Window > Devices and Simulators；也可以按 ⇧⌘2。"
            }
        } else {
            xcodeHint = "未检测到 Xcode：请先安装 Xcode。"
        }
        log("""
开发者模式助手：
1. 保持 iPhone 解锁，并在手机上点“信任此电脑”。
2. \(xcodeHint)
3. 新版 Xcode 入口：Xcode > Open Developer Tool > Device Hub；旧版入口：Window > Devices and Simulators 或 ⇧⌘2。
4. 选中这台 iPhone，等待 Xcode 准备设备完成。
5. 回到 iPhone，完全退出“设置”后重新打开。
6. 进入 设置 > 隐私与安全性，拉到最下面打开“开发者模式”。
7. 按提示重启 iPhone，重启后再确认打开。
如果仍然没有入口：确认 iOS 是 16 或更高版本，并检查这台手机是否被公司/学校 MDM 管理限制。
""")
    }

    private func findXcodeInstallations() -> [XcodeInstallation] {
        var seen = Set<String>()
        var urls: [URL] = []

        func add(_ path: String) {
            let expanded = (path as NSString).expandingTildeInPath
            guard expanded.hasSuffix(".app"), FileManager.default.fileExists(atPath: expanded) else { return }
            guard !seen.contains(expanded) else { return }
            seen.insert(expanded)
            urls.append(URL(fileURLWithPath: expanded))
        }

        add("/Applications/Xcode-beta.app")
        add("/Applications/Xcode.app")

        let selected = runCommand(["/usr/bin/xcode-select", "-p"], timeout: 5).output
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if selected.contains(".app/Contents/Developer"),
           let range = selected.range(of: ".app/Contents/Developer") {
            add(String(selected[..<range.upperBound]).replacingOccurrences(of: "/Contents/Developer", with: ""))
        }

        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/mdfind")
        process.arguments = ["kMDItemCFBundleIdentifier == 'com.apple.dt.Xcode'"]
        let pipe = Pipe()
        process.standardOutput = pipe
        try? process.run()
        process.waitUntilExit()
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let output = String(data: data, encoding: .utf8) ?? ""
        for line in output.split(separator: "\n") {
            add(String(line))
        }

        let installs = urls.map { url in
            XcodeInstallation(appURL: url, version: xcodeVersion(for: url))
        }

        return installs.sorted { lhs, rhs in
            switch (lhs.majorVersion, rhs.majorVersion) {
            case let (l?, r?) where l != r:
                return l > r
            default:
                if lhs.hasDeviceHub != rhs.hasDeviceHub {
                    return lhs.hasDeviceHub && !rhs.hasDeviceHub
                }
                return lhs.name < rhs.name
            }
        }
    }

    private func preferredXcodeInstallation() -> XcodeInstallation? {
        findXcodeInstallations().first
    }

    private func xcodeVersion(for appURL: URL) -> String {
        if let bundle = Bundle(url: appURL),
           let version = bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String,
           !version.isEmpty {
            return version
        }
        let plist = appURL.appendingPathComponent("Contents/Info.plist").path
        let result = runCommand(["/usr/libexec/PlistBuddy", "-c", "Print :CFBundleShortVersionString", plist], timeout: 5)
        let value = result.output.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? "未知版本" : value
    }

    private func openLegacyDevicesAndSimulatorsWindow() {
        let script = """
        tell application "Xcode" to activate
        delay 0.5
        tell application "System Events"
          tell process "Xcode"
            try
              click menu item "Devices and Simulators" of menu "Window" of menu bar item "Window" of menu bar 1
            on error
              keystroke "2" using {command down, shift down}
            end try
          end tell
        end tell
        """
        let result = runCommand(["/usr/bin/osascript", "-e", script], timeout: 10)
        if result.code == 0 {
            log("已尝试打开旧版 Xcode 的 Devices and Simulators。")
        } else {
            log("无法自动打开 Devices and Simulators。请在 Xcode 中手动按 ⇧⌘2。\(result.output.isEmpty ? "" : "\n\(result.output)")")
        }
    }

    private func terminateLocalSimulationProcesses() {
        guard let pymo = pymoPath() else { return }
        if let process = activeSimulationProcess, process.isRunning {
            process.terminate()
            log("已结束当前 App 启动的模拟定位进程。")
            activeSimulationProcess = nil
            Thread.sleep(forTimeInterval: 0.5)
        }
        let result = runCommand(["/bin/ps", "-axo", "pid=,command="], timeout: 5)
        guard result.code == 0 else { return }

        var killed = 0
        for line in result.output.split(separator: "\n").map(String.init) {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            guard let spaceIndex = trimmed.firstIndex(where: { $0 == " " || $0 == "\t" }) else { continue }
            let pidText = String(trimmed[..<spaceIndex])
            let command = String(trimmed[spaceIndex...])
            let isSimulationSetter = command.contains(pymo)
                && command.contains(" developer ")
                && command.contains("simulate-location")
                && (command.contains(" set ") || command.contains(" play "))
            guard isSimulationSetter else { continue }
            let killResult = runCommand(["/bin/kill", pidText], timeout: 3)
            if killResult.code == 0 {
                killed += 1
            }
        }

        if killed > 0 {
            log("已结束 \(killed) 个本机残留的模拟定位进程。")
            Thread.sleep(forTimeInterval: 0.5)
        }
    }

    private func resolvePath(version: String) -> String {
        let selected = channelPopup.titleOfSelectedItem ?? "auto"
        if selected == "ios17_dvt" || selected == "ios16_legacy" {
            return selected
        }
        guard let majorText = version.split(separator: ".").first, let major = Int(majorText) else {
            log("未能自动判断 iOS 版本，将先尝试 iOS 17+ DVT，再尝试旧通道。")
            return "auto_unknown"
        }
        if major >= 17 {
            log("检测到 iOS \(version)，使用 DVT 定位通道。")
            return "ios17_dvt"
        }
        log("检测到 iOS \(version)，使用旧定位通道。")
        return "ios16_legacy"
    }

    private func prepareDevice(pymo: String, udid: String, path: String) throws {
        var cmd = [pymo, "mounter", "auto-mount", "--udid", udid]
        if userspaceCheck.state == .on && (path == "ios17_dvt" || path == "auto_unknown") {
            cmd.append("--userspace")
        }
        log("准备 DeveloperDiskImage...")
        let result = runCommand(cmd, timeout: 120)
        if isDeviceLocked(result.output) {
            log("iPhone 当前处于锁屏状态，无法准备 DeveloperDiskImage。")
            throw ToolError.message("iPhone 当前处于锁屏状态。请解锁 iPhone，保持屏幕亮起，然后重新点击“设置到此位置”。")
        }
        log(result.output.isEmpty ? "命令完成。" : conciseOutput(result.output))
        if !commandSucceeded(result) && !result.output.lowercased().contains("already mounted") {
            log("DeveloperDiskImage 准备失败；继续尝试定位命令，若失败请检查开发者模式/信任状态。")
        }
    }

    private func realLocationCommands(pymo: String, udid: String, path: String, action: String, lat: Double?, lon: Double?) -> [[String]] {
        var dvt = [pymo, "developer", "dvt", "simulate-location", action, "--udid", udid]
        if userspaceCheck.state == .on {
            dvt.append("--userspace")
        }
        var legacy = [pymo, "developer", "simulate-location", action, "--udid", udid]
        if action == "set", let lat, let lon {
            let coords = ["--", String(format: "%.7f", lat), String(format: "%.7f", lon)]
            dvt += coords
            legacy += coords
        }
        if path == "ios17_dvt" {
            return [dvt]
        }
        if path == "ios16_legacy" {
            return [legacy]
        }
        return [dvt, legacy]
    }

    private func startLongRunningSimulation(_ commands: [[String]], failureMessage: String) throws {
        var outputs: [String] = []

        for cmd in commands {
            log("$ \(displayCommand(cmd))")

            let process = Process()
            guard let first = cmd.first else { continue }
            process.executableURL = URL(fileURLWithPath: first)
            process.arguments = Array(cmd.dropFirst())
            process.environment = ProcessInfo.processInfo.environment.merging([
                "PYTHONUTF8": "1",
                "PYMOBILEDEVICE3_NO_COLOR": "1"
            ]) { _, new in new }

            let pipe = Pipe()
            process.standardOutput = pipe
            process.standardError = pipe

            let outputLock = NSLock()
            var output = ""
            pipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
                let data = handle.availableData
                guard !data.isEmpty, let text = String(data: data, encoding: .utf8) else { return }
                outputLock.lock()
                output += text
                outputLock.unlock()
                let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty {
                    self?.log(self?.conciseOutput(trimmed) ?? trimmed)
                }
            }

            do {
                try process.run()
            } catch {
                pipe.fileHandleForReading.readabilityHandler = nil
                outputs.append(error.localizedDescription)
                continue
            }

            Thread.sleep(forTimeInterval: 6.0)

            outputLock.lock()
            let currentOutput = output
            outputLock.unlock()

            if isDeviceLocked(currentOutput) {
                pipe.fileHandleForReading.readabilityHandler = nil
                process.terminate()
                throw ToolError.message("iPhone 当前处于锁屏状态。请解锁 iPhone，保持屏幕亮起，然后重试。")
            }

            if process.isRunning {
                DispatchQueue.main.sync {
                    if let previous = self.activeSimulationProcess, previous.isRunning {
                        previous.terminate()
                    }
                    self.activeSimulationProcess = process
                }
                log("定位模拟已启动。底层命令会保持连接；需要恢复真实定位时点击“结束模拟”。")
                return
            }

            pipe.fileHandleForReading.readabilityHandler = nil
            let result = CommandResult(code: process.terminationStatus, output: currentOutput.trimmingCharacters(in: .whitespacesAndNewlines))
            if commandSucceeded(result) {
                log("定位命令执行成功。")
                return
            }
            if !result.output.isEmpty {
                outputs.append(result.output)
            }
        }

        let hint = "请确认：iPhone 已解锁并信任此 Mac；设置 > 隐私与安全性 > 开发者模式 已开启；没有其他工具正在占用设备；必要时重新插拔数据线。"
        let detail = outputs.joined(separator: "\n\n")
        throw ToolError.message("\(failureMessage)\n\n\(hint)\(detail.isEmpty ? "" : "\n\n最后输出：\n\(detail)")")
    }

    private func runFirstSuccess(_ commands: [[String]], failureMessage: String) throws {
        var outputs: [String] = []
        for cmd in commands {
            log("$ \(displayCommand(cmd))")
            let result = runCommand(cmd, timeout: 90)
            if !result.output.isEmpty {
                log(conciseOutput(result.output))
                outputs.append(result.output)
            }
            if isDeviceLocked(result.output) {
                throw ToolError.message("iPhone 当前处于锁屏状态。请解锁 iPhone，保持屏幕亮起，然后重试。")
            }
            if commandSucceeded(result) {
                log("定位命令执行成功。")
                return
            }
        }
        let hint = "请确认：iPhone 已解锁并信任此 Mac；设置 > 隐私与安全性 > 开发者模式 已开启；没有其他工具正在占用设备；必要时重新插拔数据线。"
        let detail = outputs.joined(separator: "\n\n")
        throw ToolError.message("\(failureMessage)\n\n\(hint)\(detail.isEmpty ? "" : "\n\n最后输出：\n\(detail)")")
    }

    private func runClearCommands(_ commands: [[String]], failureMessage: String) throws {
        var outputs: [String] = []
        for cmd in commands {
            log("$ \(displayCommand(cmd))")
            let result = runCommandBriefly(cmd, settleSeconds: 8.0)
            if !result.output.isEmpty {
                log(conciseOutput(result.output))
                outputs.append(result.output)
            }
            if isDeviceLocked(result.output) {
                throw ToolError.message("iPhone 当前处于锁屏状态。请解锁 iPhone，保持屏幕亮起，然后重试。")
            }
            if result.accepted {
                log("结束模拟命令已发送。请在 iPhone 上确认定位已恢复。")
                return
            }
        }
        let hint = "请保持 iPhone 解锁并信任此 Mac；如果刚设置过定位，请等待几秒后再点一次“结束模拟”。"
        let detail = outputs.joined(separator: "\n\n")
        throw ToolError.message("\(failureMessage)\n\n\(hint)\(detail.isEmpty ? "" : "\n\n最后输出：\n\(detail)")")
    }

    private func runCommandBriefly(_ args: [String], settleSeconds: TimeInterval) -> (accepted: Bool, output: String) {
        guard let first = args.first else {
            return (false, "Empty command")
        }

        let process = Process()
        process.executableURL = URL(fileURLWithPath: first)
        process.arguments = Array(args.dropFirst())
        process.environment = ProcessInfo.processInfo.environment.merging([
            "PYTHONUTF8": "1",
            "PYMOBILEDEVICE3_NO_COLOR": "1"
        ]) { _, new in new }

        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe

        let outputLock = NSLock()
        var output = ""
        pipe.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            guard !data.isEmpty, let text = String(data: data, encoding: .utf8) else { return }
            outputLock.lock()
            output += text
            outputLock.unlock()
        }

        do {
            try process.run()
        } catch {
            pipe.fileHandleForReading.readabilityHandler = nil
            return (false, error.localizedDescription)
        }

        let deadline = Date().addingTimeInterval(settleSeconds)
        while process.isRunning && Date() < deadline {
            Thread.sleep(forTimeInterval: 0.05)
        }

        if process.isRunning {
            process.terminate()
            Thread.sleep(forTimeInterval: 0.3)
            pipe.fileHandleForReading.readabilityHandler = nil
            outputLock.lock()
            let text = output.trimmingCharacters(in: .whitespacesAndNewlines)
            outputLock.unlock()
            return (!isDeviceLocked(text) && !outputContainsFailure(text), text)
        }

        pipe.fileHandleForReading.readabilityHandler = nil
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        if let text = String(data: data, encoding: .utf8), !text.isEmpty {
            outputLock.lock()
            output += text
            outputLock.unlock()
        }
        outputLock.lock()
        let text = output.trimmingCharacters(in: .whitespacesAndNewlines)
        outputLock.unlock()
        let result = CommandResult(code: process.terminationStatus, output: text)
        return (commandSucceeded(result), text)
    }

    private func selectedRealDevice() throws -> ToolDevice {
        guard let device = selectedRealDeviceIfAvailable() else {
            throw ToolError.message("请先连接 iPhone，点击“刷新设备”，并选择一台 iPhone。")
        }
        return device
    }

    private func selectedRealDeviceOrSingleConnected(pymo: String) throws -> ToolDevice {
        if let device = selectedRealDeviceIfAvailable() {
            return device
        }

        let devices = try connectedRealDevices(pymo: pymo)
        DispatchQueue.main.async {
            self.realDevices = devices
            self.realPopup.removeAllItems()
            self.realPopup.addItems(withTitles: devices.map { self.realLabel($0) })
            if devices.count == 1 {
                self.realPopup.selectItem(at: 0)
            }
        }

        if devices.count == 1, let device = devices.first {
            log("未从下拉框读取到选择，自动使用唯一连接的 iPhone：\(realLabel(device))")
            return device
        }
        if devices.isEmpty {
            throw ToolError.message("没有检测到 iPhone。请连接 iPhone、解锁并信任电脑，然后点击“刷新设备”。")
        }
        throw ToolError.message("检测到多台 iPhone。请先点击“刷新设备”，并在下拉框选择要结束模拟的 iPhone。")
    }

    private func selectedRealDeviceIfAvailable() -> ToolDevice? {
        var device: ToolDevice?
        let readSelection = {
            let index = self.realPopup.indexOfSelectedItem
            if self.realDevices.indices.contains(index) {
                device = self.realDevices[index]
            }
        }
        if Thread.isMainThread {
            readSelection()
        } else {
            DispatchQueue.main.sync(execute: readSelection)
        }
        return device
    }

    private func selectedSimulator() throws -> ToolDevice {
        let index = simPopup.indexOfSelectedItem
        guard simDevices.indices.contains(index) else {
            throw ToolError.message("请先选择一个 iOS 模拟器。")
        }
        return simDevices[index]
    }

    private func readCoordinates() -> (Double, Double)? {
        guard let lat = Double(latField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)),
              let lon = Double(lonField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)) else {
            showError("经纬度必须是数字，例如 31.230416 和 121.473701。")
            return nil
        }
        guard (-90...90).contains(lat) else {
            showError("纬度范围必须在 -90 到 90 之间。")
            return nil
        }
        guard (-180...180).contains(lon) else {
            showError("经度范围必须在 -180 到 180 之间。")
            return nil
        }
        return (lat, lon)
    }

    private func pymoPath() -> String? {
        let local = toolRoot.appendingPathComponent(".venv/bin/pymobiledevice3").path
        if FileManager.default.isExecutableFile(atPath: local) {
            return local
        }
        for candidate in ["/opt/homebrew/bin/pymobiledevice3", "/usr/local/bin/pymobiledevice3"] {
            if FileManager.default.isExecutableFile(atPath: candidate) {
                return candidate
            }
        }
        return nil
    }

    private func runCommand(_ args: [String], timeout: TimeInterval) -> CommandResult {
        guard let first = args.first else {
            return CommandResult(code: 127, output: "Empty command")
        }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: first)
        process.arguments = Array(args.dropFirst())
        process.environment = ProcessInfo.processInfo.environment.merging([
            "PYTHONUTF8": "1",
            "PYMOBILEDEVICE3_NO_COLOR": "1"
        ]) { _, new in new }

        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
        } catch {
            return CommandResult(code: 127, output: error.localizedDescription)
        }

        let deadline = Date().addingTimeInterval(timeout)
        while process.isRunning && Date() < deadline {
            Thread.sleep(forTimeInterval: 0.05)
        }
        if process.isRunning {
            process.terminate()
            return CommandResult(code: 124, output: "Command timed out after \(Int(timeout))s.")
        }

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let text = String(data: data, encoding: .utf8) ?? ""
        return CommandResult(code: process.terminationStatus, output: text.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    private func commandSucceeded(_ result: CommandResult) -> Bool {
        if result.code != 0 {
            return false
        }
        let text = result.output.lowercased()
        if text.contains("already mounted") {
            return true
        }
        return !outputContainsFailure(text)
    }

    private func outputContainsFailure(_ text: String) -> Bool {
        let text = text.lowercased()
        let failures = ["error", "traceback", "device not found", "no device", "unable to", "failed"]
        return failures.contains { text.contains($0) }
    }

    private func isDeviceLocked(_ text: String) -> Bool {
        text.localizedCaseInsensitiveContains("DeviceLocked")
    }

    private func conciseOutput(_ text: String) -> String {
        if isDeviceLocked(text) {
            return "后端返回 DeviceLocked：iPhone 已锁屏。"
        }
        if text.count <= 1200 {
            return text
        }
        let lines = text.split(separator: "\n").map(String.init)
        let important = lines.filter { line in
            let lower = line.lowercased()
            return lower.contains("error") || lower.contains("exception") || lower.contains("failed") || lower.contains("unable")
        }
        if !important.isEmpty {
            return important.prefix(8).joined(separator: "\n")
        }
        return String(text.prefix(1200)) + "\n..."
    }

    private func parseUDIDs(_ text: String) -> [String] {
        if let data = text.data(using: .utf8),
           let list = try? JSONSerialization.jsonObject(with: data) as? [String] {
            return list
        }
        return text
            .split(separator: "\n")
            .map { $0.trimmingCharacters(in: CharacterSet(charactersIn: " \t,\"'[]")) }
            .filter { !$0.isEmpty }
    }

    private func jsonObject(_ text: String) -> [String: Any]? {
        guard let data = text.data(using: .utf8) else { return nil }
        return try? JSONSerialization.jsonObject(with: data) as? [String: Any]
    }

    private func realLabel(_ device: ToolDevice) -> String {
        let version = device.version.isEmpty ? "" : " iOS \(device.version)"
        return "\(device.name)\(version) - \(device.id)"
    }

    private func simLabel(_ device: ToolDevice) -> String {
        let runtime = device.runtime.isEmpty ? "" : " / \(device.runtime)"
        return "\(device.name) [\(device.state)]\(runtime) - \(device.id)"
    }

    private func shortID(_ text: String) -> String {
        String(text.prefix(8)) + "..."
    }

    private func displayCommand(_ args: [String]) -> String {
        args.map { part in
            if part.range(of: #"^[A-Za-z0-9_./:=,+-]+$"#, options: .regularExpression) != nil {
                return part
            }
            return "'" + part.replacingOccurrences(of: "'", with: "'\"'\"'") + "'"
        }.joined(separator: " ")
    }

    private func log(_ message: String) {
        DispatchQueue.main.async {
            let stamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
            self.logView.string += "[\(stamp)] \(message)\n"
            self.logView.scrollToEndOfDocument(nil)
        }
    }

    private func showError(_ message: String) {
        let alert = NSAlert()
        alert.messageText = "操作失败"
        alert.informativeText = message
        alert.alertStyle = .warning
        alert.beginSheetModal(for: window)
    }
}

enum ToolError: LocalizedError {
    case message(String)

    var errorDescription: String? {
        switch self {
        case .message(let text):
            return text
        }
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
