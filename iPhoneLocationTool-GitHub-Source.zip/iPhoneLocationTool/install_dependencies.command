#!/bin/bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

echo "Creating local Python environment..."
python3 -m venv .venv

echo "Installing iPhone developer backend..."
".venv/bin/python" -m pip install --upgrade pip
".venv/bin/python" -m pip install -r requirements.txt

echo
echo "Done. You can now double-click run.command or iPhone Location Tool.app."
read -r -p "Press Enter to close this window..."
