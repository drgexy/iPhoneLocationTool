#!/bin/bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APP_DIR"

choose_python_with_tk() {
  for candidate in /usr/bin/python3 /Applications/Xcode.app/Contents/Developer/usr/bin/python3 "$(command -v python3)"; do
    [[ -n "$candidate" && -x "$candidate" ]] || continue
    if "$candidate" - <<'PY' >/dev/null 2>&1
import tkinter
PY
    then
      echo "$candidate"
      return 0
    fi
  done
  return 1
}

PYTHON="$(choose_python_with_tk)"

exec "$PYTHON" "$APP_DIR/iPhoneLocationTool.py"
