#!/usr/bin/env python3
"""
iPhone Location Tool

A local macOS utility for development/testing location simulation on devices
owned by the user. It wraps Apple's simulator tooling and pymobiledevice3's
developer services for real iPhone devices with Developer Mode enabled.
"""

from __future__ import annotations

import json
import os
import queue
import re
import signal
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk


APP_DIR = Path(__file__).resolve().parent
LOCAL_PYMO = APP_DIR / ".venv" / "bin" / "pymobiledevice3"
XCODE_APP = Path("/Applications/Xcode.app")


PRESETS = {
    "Apple Park": (37.334900, -122.009020),
    "英国 伦敦眼": (51.503324, -0.119543),
    "上海 人民广场": (31.230416, 121.473701),
    "北京 天安门": (39.908722, 116.397499),
    "深圳 市民中心": (22.543096, 114.057865),
    "香港 中环": (22.281928, 114.158997),
    "东京站": (35.681236, 139.767125),
    "纽约 自由女神像": (40.689249, -74.044500),
}


@dataclass
class CommandResult:
    args: list[str]
    returncode: int
    stdout: str
    stderr: str

    @property
    def text(self) -> str:
        return "\n".join(part for part in [self.stdout.strip(), self.stderr.strip()] if part)


def clean_env() -> dict[str, str]:
    env = os.environ.copy()
    env.setdefault("PYTHONUTF8", "1")
    env.setdefault("PYMOBILEDEVICE3_NO_COLOR", "1")
    return env


def find_pymobiledevice3() -> Optional[str]:
    if LOCAL_PYMO.exists():
        return str(LOCAL_PYMO)
    return shutil.which("pymobiledevice3")


def find_xcrun() -> Optional[str]:
    return shutil.which("xcrun")


def run_command(args: list[str], timeout: int = 60) -> CommandResult:
    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=clean_env(),
        )
        return CommandResult(args, proc.returncode, proc.stdout, proc.stderr)
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout if isinstance(exc.stdout, str) else ""
        stderr = exc.stderr if isinstance(exc.stderr, str) else ""
        return CommandResult(args, 124, stdout, stderr + f"\nCommand timed out after {timeout}s.")
    except FileNotFoundError as exc:
        return CommandResult(args, 127, "", str(exc))


def command_succeeded(result: CommandResult) -> bool:
    if result.returncode != 0:
        return False
    text = result.text
    if "already mounted" in text.lower():
        return True
    error_patterns = [
        r"\bERROR\b",
        r"\bError\b",
        r"\bTraceback\b",
        r"Device not found",
        r"No device",
        r"Unable to",
        r"Failed",
    ]
    return not any(re.search(pattern, text, re.IGNORECASE) for pattern in error_patterns)


def is_device_locked(text: str) -> bool:
    return "devicelocked" in text.lower()


def concise_output(text: str) -> str:
    if is_device_locked(text):
        return "后端返回 DeviceLocked：iPhone 已锁屏。"
    if len(text) <= 1200:
        return text
    lines = text.splitlines()
    important = [
        line
        for line in lines
        if any(token in line.lower() for token in ["error", "exception", "failed", "unable"])
    ]
    if important:
        return "\n".join(important[:8])
    return text[:1200] + "\n..."


def parse_lockdown_value(text: str, key: str) -> str:
    try:
        payload = json.loads(text)
        if isinstance(payload, dict) and key in payload:
            return str(payload[key])
    except json.JSONDecodeError:
        pass
    patterns = [
        rf"['\"]{re.escape(key)}['\"]\s*:\s*['\"]([^'\"]+)['\"]",
        rf"\b{re.escape(key)}\b\s*=\s*([^;\n]+)",
        rf"\b{re.escape(key)}\b\s*:\s*([^\n]+)",
        rf"<key>{re.escape(key)}</key>\s*<string>([^<]+)</string>",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.MULTILINE)
        if match:
            return match.group(1).strip().strip('"').strip("'")
    return ""


def ios_major(version: str) -> Optional[int]:
    match = re.match(r"\s*(\d+)", version or "")
    if not match:
        return None
    return int(match.group(1))


def validate_coordinate(raw_lat: str, raw_lon: str) -> tuple[float, float]:
    try:
        lat = float(raw_lat.strip())
        lon = float(raw_lon.strip())
    except ValueError as exc:
        raise ValueError("经纬度必须是数字，例如 31.230416 和 121.473701。") from exc
    if not -90 <= lat <= 90:
        raise ValueError("纬度范围必须在 -90 到 90 之间。")
    if not -180 <= lon <= 180:
        raise ValueError("经度范围必须在 -180 到 180 之间。")
    return lat, lon


def format_coord(value: float) -> str:
    return f"{value:.6f}"


def build_gpx(lat: float, lon: float, name: str = "Simulated Location") -> str:
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="iPhone Location Tool" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>{name}</name>
  </metadata>
  <wpt lat="{lat:.7f}" lon="{lon:.7f}">
    <name>{name}</name>
  </wpt>
</gpx>
"""


class LocationToolApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("iPhone Location Tool")
        self.geometry("980x720")
        self.minsize(860, 620)

        self.real_devices: list[dict[str, str]] = []
        self.sim_devices: list[dict[str, str]] = []
        self.log_queue: queue.Queue[str] = queue.Queue()

        self.mode_var = tk.StringVar(value="real")
        self.real_device_var = tk.StringVar()
        self.sim_device_var = tk.StringVar(value="booted")
        self.lat_var = tk.StringVar(value=format_coord(PRESETS["上海 人民广场"][0]))
        self.lon_var = tk.StringVar(value=format_coord(PRESETS["上海 人民广场"][1]))
        self.preset_var = tk.StringVar(value="上海 人民广场")
        self.ios_path_var = tk.StringVar(value="auto")
        self.userspace_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value="正在初始化...")

        self._configure_style()
        self._build_ui()
        self.after(100, self._pump_logs)
        self.after(250, self.refresh_all)

    def _configure_style(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Arial", 20, "bold"))
        style.configure("Section.TLabelframe.Label", font=("Arial", 12, "bold"))
        style.configure("Primary.TButton", font=("Arial", 11, "bold"), padding=(14, 8))
        style.configure("Danger.TButton", font=("Arial", 11, "bold"), padding=(14, 8))
        style.configure("Plain.TButton", padding=(10, 6))

    def _build_ui(self) -> None:
        root = ttk.Frame(self, padding=18)
        root.pack(fill=tk.BOTH, expand=True)

        header = ttk.Frame(root)
        header.pack(fill=tk.X)
        ttk.Label(header, text="iPhone Location Tool", style="Title.TLabel").pack(side=tk.LEFT)
        ttk.Button(header, text="刷新设备", command=self.refresh_all, style="Plain.TButton").pack(side=tk.RIGHT)

        notice = (
            "仅用于你本人设备上的 App 开发、调试和测试定位。使用前请在 iPhone 上开启开发者模式，"
            "连接并信任这台 Mac；测试后请点击“清除模拟定位”。"
        )
        ttk.Label(root, text=notice, wraplength=900, foreground="#4a4a4a").pack(fill=tk.X, pady=(10, 14))

        body = ttk.Frame(root)
        body.pack(fill=tk.BOTH, expand=True)
        body.columnconfigure(0, weight=0, minsize=360)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        left = ttk.Frame(body)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        right = ttk.Frame(body)
        right.grid(row=0, column=1, sticky="nsew")
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)

        self._build_target_panel(left)
        self._build_location_panel(left)
        self._build_action_panel(left)
        self._build_log_panel(right)

        status = ttk.Label(root, textvariable=self.status_var, anchor=tk.W)
        status.pack(fill=tk.X, pady=(10, 0))

    def _build_target_panel(self, parent: ttk.Frame) -> None:
        panel = ttk.LabelFrame(parent, text="目标设备", padding=12, style="Section.TLabelframe")
        panel.pack(fill=tk.X, pady=(0, 12))

        mode_row = ttk.Frame(panel)
        mode_row.pack(fill=tk.X, pady=(0, 10))
        ttk.Radiobutton(mode_row, text="真机 iPhone", variable=self.mode_var, value="real").pack(side=tk.LEFT)
        ttk.Radiobutton(mode_row, text="iOS 模拟器", variable=self.mode_var, value="sim").pack(side=tk.LEFT, padx=(18, 0))

        ttk.Label(panel, text="已连接 iPhone").pack(anchor=tk.W)
        self.real_combo = ttk.Combobox(panel, textvariable=self.real_device_var, state="readonly", width=42)
        self.real_combo.pack(fill=tk.X, pady=(4, 10))

        ttk.Label(panel, text="模拟器").pack(anchor=tk.W)
        self.sim_combo = ttk.Combobox(panel, textvariable=self.sim_device_var, state="readonly", width=42)
        self.sim_combo.pack(fill=tk.X, pady=(4, 10))

        ttk.Label(panel, text="真机定位通道").pack(anchor=tk.W)
        self.ios_path_combo = ttk.Combobox(
            panel,
            textvariable=self.ios_path_var,
            state="readonly",
            values=[
                "auto",
                "ios17_dvt",
                "ios16_legacy",
            ],
        )
        self.ios_path_combo.pack(fill=tk.X, pady=(4, 8))
        ttk.Label(
            panel,
            text="auto 会先读取 iOS 版本；iOS 17+ 使用 DVT，iOS 16 及以下使用旧通道。",
            wraplength=320,
            foreground="#666666",
        ).pack(anchor=tk.W)
        ttk.Checkbutton(
            panel,
            text="iOS 17+ 使用免管理员 userspace tunnel",
            variable=self.userspace_var,
        ).pack(anchor=tk.W, pady=(8, 0))

    def _build_location_panel(self, parent: ttk.Frame) -> None:
        panel = ttk.LabelFrame(parent, text="定位坐标", padding=12, style="Section.TLabelframe")
        panel.pack(fill=tk.X, pady=(0, 12))

        ttk.Label(panel, text="常用位置").pack(anchor=tk.W)
        preset_combo = ttk.Combobox(panel, textvariable=self.preset_var, state="readonly", values=list(PRESETS.keys()))
        preset_combo.pack(fill=tk.X, pady=(4, 10))
        preset_combo.bind("<<ComboboxSelected>>", lambda _event: self.apply_preset())

        grid = ttk.Frame(panel)
        grid.pack(fill=tk.X)
        grid.columnconfigure(1, weight=1)
        ttk.Label(grid, text="纬度").grid(row=0, column=0, sticky=tk.W, pady=4)
        ttk.Entry(grid, textvariable=self.lat_var).grid(row=0, column=1, sticky="ew", padx=(10, 0), pady=4)
        ttk.Label(grid, text="经度").grid(row=1, column=0, sticky=tk.W, pady=4)
        ttk.Entry(grid, textvariable=self.lon_var).grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=4)

        ttk.Button(panel, text="导出 GPX", command=self.export_gpx, style="Plain.TButton").pack(fill=tk.X, pady=(12, 0))

    def _build_action_panel(self, parent: ttk.Frame) -> None:
        panel = ttk.LabelFrame(parent, text="操作", padding=12, style="Section.TLabelframe")
        panel.pack(fill=tk.X)

        ttk.Button(panel, text="设置到此位置", command=self.set_location, style="Primary.TButton").pack(fill=tk.X, pady=(0, 10))
        ttk.Button(panel, text="清除模拟定位", command=self.clear_location, style="Danger.TButton").pack(fill=tk.X, pady=(0, 10))
        ttk.Button(panel, text="检查环境", command=self.check_environment, style="Plain.TButton").pack(fill=tk.X)

    def _build_log_panel(self, parent: ttk.Frame) -> None:
        top = ttk.Frame(parent)
        top.grid(row=0, column=0, sticky="ew")
        ttk.Label(top, text="运行日志", font=("Arial", 12, "bold")).pack(side=tk.LEFT)
        ttk.Button(top, text="清空", command=self.clear_log, style="Plain.TButton").pack(side=tk.RIGHT)

        frame = ttk.Frame(parent)
        frame.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.log_text = tk.Text(frame, wrap=tk.WORD, height=18, font=("Menlo", 12))
        scroll = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")

    def apply_preset(self) -> None:
        lat, lon = PRESETS[self.preset_var.get()]
        self.lat_var.set(format_coord(lat))
        self.lon_var.set(format_coord(lon))

    def enqueue_log(self, message: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        self.log_queue.put(f"[{stamp}] {message}\n")

    def _pump_logs(self) -> None:
        try:
            while True:
                message = self.log_queue.get_nowait()
                self.log_text.insert(tk.END, message)
                self.log_text.see(tk.END)
        except queue.Empty:
            pass
        self.after(100, self._pump_logs)

    def clear_log(self) -> None:
        self.log_text.delete("1.0", tk.END)

    def run_background(self, title: str, worker: Callable[[], None]) -> None:
        self.status_var.set(title)
        threading.Thread(target=self._run_worker, args=(title, worker), daemon=True).start()

    def _run_worker(self, title: str, worker: Callable[[], None]) -> None:
        try:
            worker()
            self.after(0, lambda: self.status_var.set("完成"))
        except Exception as exc:  # noqa: BLE001 - GUI should surface all user-facing failures.
            self.enqueue_log(f"失败：{exc}")
            self.after(0, lambda: self.status_var.set("失败"))
            self.after(0, lambda: messagebox.showerror("操作失败", str(exc)))

    def check_environment(self) -> None:
        def worker() -> None:
            xcrun = find_xcrun()
            pymo = find_pymobiledevice3()
            self.enqueue_log("环境检查：")
            self.enqueue_log(f"- xcrun: {xcrun or '未找到，请安装/打开 Xcode'}")
            self.enqueue_log(f"- pymobiledevice3: {pymo or '未找到，请先运行 install_dependencies.command'}")
            self.enqueue_log(f"- Xcode.app: {'存在' if XCODE_APP.exists() else '未找到 /Applications/Xcode.app'}")
            if xcrun:
                result = run_command([xcrun, "simctl", "location", "booted", "list"], timeout=12)
                if command_succeeded(result):
                    self.enqueue_log("- 模拟器定位命令可用")
                else:
                    self.enqueue_log("- 模拟器定位命令返回信息：" + (result.text or "无输出"))
            if pymo:
                result = run_command([pymo, "version"], timeout=15)
                self.enqueue_log("- pymobiledevice3 版本：" + (result.text or "可执行"))

        self.run_background("正在检查环境...", worker)

    def refresh_all(self) -> None:
        def worker() -> None:
            self.refresh_real_devices()
            self.refresh_simulators()
            self.enqueue_log("设备列表已刷新。")

        self.run_background("正在刷新设备...", worker)

    def refresh_real_devices(self) -> None:
        pymo = find_pymobiledevice3()
        devices: list[dict[str, str]] = []
        if not pymo:
            self.enqueue_log("未找到 pymobiledevice3：真机模式暂不可用。")
        else:
            result = run_command([pymo, "usbmux", "list", "--simple"], timeout=20)
            if result.returncode != 0:
                self.enqueue_log("读取 iPhone 列表失败：" + (result.text or "无输出"))
            else:
                udids = self.parse_usbmux_udids(result.stdout)
                for udid in udids:
                    device = {"udid": udid, "name": "iPhone", "version": ""}
                    info = run_command([pymo, "lockdown", "info", "--udid", udid], timeout=20)
                    if command_succeeded(info):
                        device["name"] = parse_lockdown_value(info.stdout, "DeviceName") or "iPhone"
                        device["version"] = parse_lockdown_value(info.stdout, "ProductVersion")
                    else:
                        self.enqueue_log(f"读取 {udid} 详情失败：" + (info.text or "无输出"))
                    devices.append(device)

        self.real_devices = devices
        labels = [self.real_label(item) for item in devices]
        self.after(0, lambda: self._set_combo_values(self.real_combo, self.real_device_var, labels))

    def refresh_simulators(self) -> None:
        xcrun = find_xcrun()
        simulators: list[dict[str, str]] = [{"udid": "booted", "name": "当前已启动模拟器", "state": "Booted", "runtime": ""}]
        if not xcrun:
            self.enqueue_log("未找到 xcrun：模拟器模式暂不可用。")
        else:
            result = run_command([xcrun, "simctl", "list", "devices", "--json"], timeout=20)
            if result.returncode != 0:
                self.enqueue_log("读取模拟器列表失败：" + (result.text or "无输出"))
            else:
                try:
                    payload = json.loads(result.stdout)
                    for runtime, entries in payload.get("devices", {}).items():
                        if "iOS" not in runtime:
                            continue
                        for entry in entries:
                            if not entry.get("isAvailable", True):
                                continue
                            simulators.append(
                                {
                                    "udid": entry.get("udid", ""),
                                    "name": entry.get("name", "iOS Simulator"),
                                    "state": entry.get("state", ""),
                                    "runtime": runtime.split(".")[-1].replace("-", " "),
                                }
                            )
                except json.JSONDecodeError:
                    self.enqueue_log("模拟器列表 JSON 解析失败。")

        self.sim_devices = simulators
        labels = [self.sim_label(item) for item in simulators]
        self.after(0, lambda: self._set_combo_values(self.sim_combo, self.sim_device_var, labels))

    @staticmethod
    def parse_usbmux_udids(text: str) -> list[str]:
        raw = text.strip()
        if not raw:
            return []
        try:
            payload = json.loads(raw)
            if isinstance(payload, list):
                return [str(item).strip() for item in payload if str(item).strip()]
        except json.JSONDecodeError:
            pass
        udids: list[str] = []
        for line in raw.splitlines():
            item = line.strip().strip(",").strip('"').strip("'")
            if item and item not in {"[", "]"}:
                udids.append(item)
        return udids

    def _set_combo_values(self, combo: ttk.Combobox, var: tk.StringVar, labels: list[str]) -> None:
        combo.configure(values=labels)
        if labels and var.get() not in labels:
            var.set(labels[0])
        if not labels:
            var.set("")

    @staticmethod
    def real_label(item: dict[str, str]) -> str:
        version = f" iOS {item['version']}" if item.get("version") else ""
        return f"{item.get('name', 'iPhone')}{version} - {item['udid']}"

    @staticmethod
    def sim_label(item: dict[str, str]) -> str:
        runtime = f" / {item['runtime']}" if item.get("runtime") else ""
        return f"{item['name']} [{item['state']}]{runtime} - {item['udid']}"

    def selected_real_device(self) -> dict[str, str]:
        label = self.real_device_var.get()
        for item in self.real_devices:
            if self.real_label(item) == label:
                return item
        raise RuntimeError("请先连接并选择一台 iPhone。")

    def selected_simulator(self) -> dict[str, str]:
        label = self.sim_device_var.get()
        for item in self.sim_devices:
            if self.sim_label(item) == label:
                return item
        raise RuntimeError("请先选择一个 iOS 模拟器。")

    def export_gpx(self) -> None:
        try:
            lat, lon = validate_coordinate(self.lat_var.get(), self.lon_var.get())
        except ValueError as exc:
            messagebox.showerror("坐标无效", str(exc))
            return
        path = filedialog.asksaveasfilename(
            title="导出 GPX",
            defaultextension=".gpx",
            initialfile="simulated-location.gpx",
            filetypes=[("GPX files", "*.gpx"), ("All files", "*.*")],
        )
        if not path:
            return
        Path(path).write_text(build_gpx(lat, lon), encoding="utf-8")
        self.enqueue_log(f"已导出 GPX：{path}")

    def set_location(self) -> None:
        try:
            lat, lon = validate_coordinate(self.lat_var.get(), self.lon_var.get())
        except ValueError as exc:
            messagebox.showerror("坐标无效", str(exc))
            return

        if self.mode_var.get() == "sim":
            self.run_background("正在设置模拟器定位...", lambda: self._set_sim_location(lat, lon))
        else:
            self.run_background("正在设置 iPhone 定位...", lambda: self._set_real_location(lat, lon))

    def clear_location(self) -> None:
        if self.mode_var.get() == "sim":
            self.run_background("正在清除模拟器定位...", self._clear_sim_location)
        else:
            self.run_background("正在清除 iPhone 模拟定位...", self._clear_real_location)

    def _set_sim_location(self, lat: float, lon: float) -> None:
        xcrun = find_xcrun()
        if not xcrun:
            raise RuntimeError("未找到 xcrun，请安装 Xcode。")
        sim = self.selected_simulator()
        target = sim["udid"]
        coord = f"{lat:.7f},{lon:.7f}"
        self.enqueue_log(f"设置模拟器 {target} 到 {coord}")
        result = run_command([xcrun, "simctl", "location", target, "set", coord], timeout=30)
        self.log_result(result)
        if not command_succeeded(result):
            raise RuntimeError("模拟器定位设置失败，请确认模拟器已启动。")

    def _clear_sim_location(self) -> None:
        xcrun = find_xcrun()
        if not xcrun:
            raise RuntimeError("未找到 xcrun，请安装 Xcode。")
        sim = self.selected_simulator()
        target = sim["udid"]
        self.enqueue_log(f"清除模拟器 {target} 的模拟定位")
        result = run_command([xcrun, "simctl", "location", target, "clear"], timeout=30)
        self.log_result(result)
        if not command_succeeded(result):
            raise RuntimeError("清除模拟器定位失败。")

    def _set_real_location(self, lat: float, lon: float) -> None:
        pymo = find_pymobiledevice3()
        if not pymo:
            raise RuntimeError("未找到 pymobiledevice3，请先运行 install_dependencies.command。")
        device = self.selected_real_device()
        udid = device["udid"]
        version = device.get("version") or self.query_ios_version(pymo, udid)
        path = self.resolve_real_path(version)
        self.prepare_device(pymo, udid, path)
        commands = self.real_location_commands(pymo, udid, path, "set", lat, lon)
        self.run_first_success(commands, "iPhone 定位设置失败。")

    def _clear_real_location(self) -> None:
        pymo = find_pymobiledevice3()
        if not pymo:
            raise RuntimeError("未找到 pymobiledevice3，请先运行 install_dependencies.command。")
        device = self.selected_real_device()
        udid = device["udid"]
        version = device.get("version") or self.query_ios_version(pymo, udid)
        path = self.resolve_real_path(version)
        commands = self.real_location_commands(pymo, udid, path, "clear", None, None)
        self.run_first_success(commands, "清除 iPhone 模拟定位失败。")

    def terminate_local_simulation_processes(self) -> None:
        pymo = find_pymobiledevice3()
        if not pymo:
            return
        result = run_command(["/bin/ps", "-axo", "pid=,command="], timeout=5)
        if result.returncode != 0:
            return
        killed = 0
        for line in result.stdout.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            pid_text, _, command = stripped.partition(" ")
            if not pid_text.isdigit():
                continue
            is_simulation_setter = (
                pymo in command
                and " developer " in command
                and "simulate-location" in command
                and (" set " in command or " play " in command)
            )
            if not is_simulation_setter:
                continue
            try:
                os.kill(int(pid_text), signal.SIGTERM)
                killed += 1
            except OSError:
                pass
        if killed:
            self.enqueue_log(f"已结束 {killed} 个本机残留的模拟定位进程。")

    def query_ios_version(self, pymo: str, udid: str) -> str:
        self.enqueue_log(f"读取 iOS 版本：{udid}")
        result = run_command([pymo, "lockdown", "info", "--udid", udid], timeout=20)
        self.log_result(result)
        if not command_succeeded(result):
            return ""
        return parse_lockdown_value(result.stdout, "ProductVersion")

    def resolve_real_path(self, version: str) -> str:
        selected = self.ios_path_var.get()
        if selected in {"ios17_dvt", "ios16_legacy"}:
            return selected
        major = ios_major(version)
        if major is None:
            self.enqueue_log("未能自动判断 iOS 版本，将先尝试 iOS 17+ DVT，再尝试旧通道。")
            return "auto_unknown"
        if major >= 17:
            self.enqueue_log(f"检测到 iOS {version}，使用 DVT 定位通道。")
            return "ios17_dvt"
        self.enqueue_log(f"检测到 iOS {version}，使用旧定位通道。")
        return "ios16_legacy"

    def prepare_device(self, pymo: str, udid: str, path: str) -> None:
        cmd = [pymo, "mounter", "auto-mount", "--udid", udid]
        if self.userspace_var.get() and path in {"ios17_dvt", "auto_unknown"}:
            cmd.append("--userspace")
        self.enqueue_log("准备 DeveloperDiskImage...")
        result = run_command(cmd, timeout=120)
        self.log_result(result)
        if is_device_locked(result.text):
            raise RuntimeError("iPhone 当前处于锁屏状态。请解锁 iPhone，保持屏幕亮起，然后重新点击“设置到此位置”。")
        if not command_succeeded(result) and "already mounted" not in result.text.lower():
            self.enqueue_log("DeveloperDiskImage 准备失败；继续尝试定位命令，若失败请检查开发者模式/信任状态。")

    def real_location_commands(
        self,
        pymo: str,
        udid: str,
        path: str,
        action: str,
        lat: Optional[float],
        lon: Optional[float],
    ) -> list[list[str]]:
        dvt = [pymo, "developer", "dvt", "simulate-location", action, "--udid", udid]
        if self.userspace_var.get():
            dvt.append("--userspace")
        legacy = [pymo, "developer", "simulate-location", action, "--udid", udid]

        if action == "set":
            assert lat is not None and lon is not None
            coords = ["--", f"{lat:.7f}", f"{lon:.7f}"]
            dvt += coords
            legacy += coords

        if path == "ios17_dvt":
            return [dvt]
        if path == "ios16_legacy":
            return [legacy]
        return [dvt, legacy]

    def run_first_success(self, commands: list[list[str]], failure_message: str) -> None:
        outputs = []
        for cmd in commands:
            self.enqueue_log("$ " + self.display_command(cmd))
            result = run_command(cmd, timeout=90)
            self.log_result(result)
            outputs.append(result.text)
            if is_device_locked(result.text):
                raise RuntimeError("iPhone 当前处于锁屏状态。请解锁 iPhone，保持屏幕亮起，然后重试。")
            if command_succeeded(result):
                self.enqueue_log("定位命令执行成功。")
                return
        detail = "\n\n".join(part for part in outputs if part)
        hint = (
            "\n\n请确认：iPhone 已解锁并信任此 Mac；设置 > 隐私与安全性 > 开发者模式 已开启；"
            "没有其他工具正在占用设备；必要时重新插拔数据线。"
        )
        raise RuntimeError(failure_message + hint + (f"\n\n最后输出：\n{detail}" if detail else ""))

    def log_result(self, result: CommandResult) -> None:
        if command_succeeded(result):
            if result.text:
                self.enqueue_log(concise_output(result.text))
            else:
                self.enqueue_log("命令完成。")
        else:
            self.enqueue_log(f"命令返回 {result.returncode}：" + (concise_output(result.text) if result.text else "无输出"))

    @staticmethod
    def display_command(args: list[str]) -> str:
        return " ".join(shlex_quote(part) for part in args)


def shlex_quote(value: str) -> str:
    if re.fullmatch(r"[A-Za-z0-9_./:=,+-]+", value):
        return value
    return "'" + value.replace("'", "'\"'\"'") + "'"


def main() -> int:
    app = LocationToolApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
